from django.contrib import admin
from .models import Concert

admin.site.register(Concert)